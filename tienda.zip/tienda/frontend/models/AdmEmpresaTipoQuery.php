<?php

namespace frontend\models;

/**
 * This is the ActiveQuery class for [[AdmEmpresaTipo]].
 *
 * @see AdmEmpresaTipo
 */
class AdmEmpresaTipoQuery extends \yii\db\ActiveQuery
{
    /*public function active()
    {
        return $this->andWhere('[[status]]=1');
    }*/

    /**
     * {@inheritdoc}
     * @return AdmEmpresaTipo[]|array
     */
    public function all($db = null)
    {
        return parent::all($db);
    }

    /**
     * {@inheritdoc}
     * @return AdmEmpresaTipo|array|null
     */
    public function one($db = null)
    {
        return parent::one($db);
    }
}
