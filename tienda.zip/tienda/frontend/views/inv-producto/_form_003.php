

        <div class="ibox">
            <div class="ibox-content  p-md">    
    <?= $form->field($model, 'inv_producto_cantidad_actual')->textInput() ?>

    <?= $form->field($model, 'inv_producto_cantidad_minima')->textInput() ?>

    <?= $form->field($model, 'inv_producto_cantidad_media')->textInput() ?>

    <?= $form->field($model, 'inv_producto_estado')->textInput() ?>

    <?= $form->field($model, 'inv_producto_ubicacion')->textInput() ?>

    <?= $form->field($model, 'logistica_producto_fecha_fabricacion')->textInput() ?>

    <?= $form->field($model, 'inv_producto_vence')->textInput() ?>

    <?= $form->field($model, 'inv_producto_vence_fecha')->textInput() ?>
</div>
</div>